"""DATA LEAKAGE CHECKS. Run in CI with the other tests.

Two kinds of leakage are tested:
  1. Training leakage: the model must not see the answer, the test rows, or information from after scoring time.
  2. Disclosure leakage: the agents must not report a rate for a group small enough to point to individual students.
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import config  # noqa: E402
import specialists  # noqa: E402,F401
from agent import tools as T  # noqa: E402
from fl.consortium import DATA, NEVER_FEATURES, load_world  # noqa: E402

world = load_world(config.CONSORTIUM)


def _rows(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def test_excluded_features_are_not_model_features():
    for name in config.EXCLUDED_FEATURES:
        assert name not in world.features, f"{name} is excluded for leakage but still a model feature"


def test_label_id_and_time_columns_are_not_features():
    banned = NEVER_FEATURES | {world.label, world.schema["id_column"]}
    assert not banned & set(world.features)


def test_no_test_row_appears_in_training():
    folder = DATA / config.CONSORTIUM
    feats = [f["name"] for f in json.load(open(folder / "schema.json"))["features"]]
    train = {tuple(r[c] for c in feats) for m in world.schema["members"] for r in _rows(folder / m["file"])}
    test = [tuple(r[c] for c in feats) for r in _rows(folder / world.schema["neutral_eval"])]
    overlap = sum(1 for t in test if t in train)
    assert overlap == 0, f"{overlap} evaluation rows also appear in a member's training file"


def test_saved_model_uses_only_allowed_features():
    path = ROOT / "models" / "federated_model.json"
    if not path.exists():
        return  # run_federation.py has not been run yet in this environment
    m = json.load(open(path))
    assert m["features"] == world.features, "the saved model was trained on a different feature list: rerun run_federation.py"


def test_small_groups_are_suppressed():
    n_min = config.MIN_CELL_SIZE
    for c in world.clients:
        r = T.call("trend_by_month", {"member": c.name})
        for month, rate in r["rate_by_month"].items():
            rows = sum(1 for x in c.rows if int(x["month"]) == month)
            assert rows >= n_min or rate is None, f"{c.name} month {month} has {rows} rows but a rate was reported"
        for seg in world.segments:
            r = T.call("segment_breakdown", {"member": c.name, "segment": seg})
            for v in r["rates"].values():
                assert isinstance(v["rows"], str) or v["rows"] >= n_min
                if isinstance(v["rows"], str):
                    assert v["outcome_rate"] is None
